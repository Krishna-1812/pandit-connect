// JavaScript for PanditConnect

document.addEventListener('DOMContentLoaded', () => {
  // Mobile navigation toggle
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (navToggle) {
    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('show');
    });
  }

  // Highlight active navigation link based on current page
  const current = window.location.pathname.split('/').pop();
  document.querySelectorAll('.nav-links a').forEach(link => {
    const href = link.getAttribute('href');
    if (href === current || (href === 'index.html' && current === '')) {
      link.classList.add('active');
    }
  });

  // Set current year in footer
  const yearSpan = document.getElementById('year');
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  // Booking form handler
  const bookingForm = document.querySelector('#booking-form');
  if (bookingForm) {
    // Pre-fill service if passed via query string
    const params = new URLSearchParams(window.location.search);
    if (params.has('service')) {
      const serviceVal = decodeURIComponent(params.get('service'));
      const serviceSelect = bookingForm.querySelector('select[name="service"]');
      if (serviceSelect) {
        // Try to set value directly; fallback to adding new option if not present
        const option = Array.from(serviceSelect.options).find(opt => opt.value === serviceVal);
        if (option) {
          serviceSelect.value = serviceVal;
        } else {
          const newOpt = document.createElement('option');
          newOpt.value = serviceVal;
          newOpt.textContent = serviceVal;
          newOpt.selected = true;
          serviceSelect.appendChild(newOpt);
        }
      }
    }
    bookingForm.addEventListener('submit', (e) => {
      e.preventDefault();
      // Collect form values
      const data = {
        name: bookingForm.querySelector('#full-name').value.trim(),
        email: bookingForm.querySelector('#email').value.trim(),
        phone: bookingForm.querySelector('#phone').value.trim(),
        location: bookingForm.querySelector('#city').value.trim(),
        service: bookingForm.querySelector('#service').value.trim(),
        pandit: bookingForm.querySelector('#pandit').value.trim(),
        date: bookingForm.querySelector('#date').value,
        time: bookingForm.querySelector('#time').value,
        details: bookingForm.querySelector('#details').value.trim(),
        submitted: Date.now()
      };
      // Save to localStorage
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      bookings.push(data);
      localStorage.setItem('bookings', JSON.stringify(bookings));
      alert('Thank you! Your booking request has been submitted. We will contact you shortly.');
      bookingForm.reset();
    });
  }

  // Contact form handler
  const contactForm = document.querySelector('#contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const data = {
        name: contactForm.querySelector('#name').value.trim(),
        email: contactForm.querySelector('#email').value.trim(),
        subject: contactForm.querySelector('#subject').value.trim(),
        message: contactForm.querySelector('#message').value.trim(),
        submitted: Date.now()
      };
      const messages = JSON.parse(localStorage.getItem('messages') || '[]');
      messages.push(data);
      localStorage.setItem('messages', JSON.stringify(messages));
      alert('Thank you for reaching out! We will get back to you soon.');
      contactForm.reset();
    });
  }

  // Pandit filter handler on pandits page
  const filterForm = document.querySelector('#filter-form');
  if (filterForm) {
    filterForm.addEventListener('input', () => {
      const locationVal = filterForm.querySelector('select[name="location"]').value.toLowerCase();
      const languageVal = filterForm.querySelector('select[name="language"]').value.toLowerCase();
      const specialtyVal = filterForm.querySelector('select[name="specialty"]').value.toLowerCase();
      document.querySelectorAll('.pandit-list .pandit-item').forEach(item => {
        const loc = item.getAttribute('data-location').toLowerCase();
        const lang = item.getAttribute('data-language').toLowerCase();
        const spec = item.getAttribute('data-specialty').toLowerCase();
        const matchLocation = locationVal === '' || loc.includes(locationVal);
        const matchLanguage = languageVal === '' || lang.includes(languageVal);
        const matchSpecialty = specialtyVal === '' || spec.includes(specialtyVal);
        if (matchLocation && matchLanguage && matchSpecialty) {
          item.style.display = '';
        } else {
          item.style.display = 'none';
        }
      });
    });
  }
});
